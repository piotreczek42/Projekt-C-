namespace Sklepzbutami_WinForms_NET8.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;

        public ICollection<Shoe>? Shoes { get; set; }
    }
}
