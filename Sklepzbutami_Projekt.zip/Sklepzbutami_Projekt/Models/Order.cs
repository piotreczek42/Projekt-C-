using Sklepzbutami_WinForms_NET8.Models;
namespace Sklepzbutami_WinForms_NET8.Models

{
    public class Order
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string PostalCode { get; set; } = string.Empty;
        public DateTime OrderDate { get; set; } = DateTime.Now;
        //public string Description { get; set; } = string.Empty;
        public Customer Customer { get; set; }
        public ICollection<OrderItem>? OrderItems { get; set; }
    }
}
