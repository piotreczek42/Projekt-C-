using Microsoft.EntityFrameworkCore;
using Sklepzbutami_WinForms_NET8.Data;
using Sklepzbutami_WinForms_NET8.Forms;
using System;
using System.Windows.Forms;

namespace Sklepzbutami_WinForms_NET8
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            var options = new DbContextOptionsBuilder<StoreContext>()
          .UseNpgsql("Host=localhost;Port=5432;Database=sklepzbutami1;Username=postgres;Password=123")
          .Options;

            var context = new StoreContext(options);


            Application.Run(new ShoesListForm(context));
        }
    }
}


