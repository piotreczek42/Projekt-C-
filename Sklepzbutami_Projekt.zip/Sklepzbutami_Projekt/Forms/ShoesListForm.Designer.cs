namespace Sklepzbutami_WinForms_NET8.Forms
{
    partial class ShoesListForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnOrders;

        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnOrder = new Button();
            btnAdd = new Button();
            btnOrders = new Button();
            btnList = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 34);
            dataGridView1.MultiSelect = false;
            dataGridView1.Name = "dataGridView1";
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(460, 278);
            dataGridView1.TabIndex = 0;
            // 
            // btnOrder
            // 
            btnOrder.Anchor = AnchorStyles.Bottom;
            btnOrder.Location = new Point(12, 5);
            btnOrder.Name = "btnOrder";
            btnOrder.Size = new Size(75, 23);
            btnOrder.TabIndex = 1;
            btnOrder.Text = "Zamów";
            btnOrder.Click += btnOrder_Click;
            // 
            // btnAdd
            // 
            btnAdd.Anchor = AnchorStyles.Bottom;
            btnAdd.Location = new Point(93, 5);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 3;
            btnAdd.Text = "Dodaj buta";
            btnAdd.Click += btnAdd_Click;
            // 
            // btnOrders
            // 
            btnOrders.Location = new Point(310, 280);
            btnOrders.Name = "btnOrders";
            btnOrders.Size = new Size(150, 30);
            btnOrders.TabIndex = 2;
            btnOrders.Text = "Lista zamówień";
            btnOrders.Click += btnOrders_Click;
            // 
            // btnList
            // 
            btnList.Anchor = AnchorStyles.Bottom;
            btnList.Location = new Point(174, 5);
            btnList.Name = "btnList";
            btnList.Size = new Size(115, 23);
            btnList.TabIndex = 4;
            btnList.Text = "Lista Zamowień";
            btnList.Click += Button1_Click;
            // 
            // ShoesListForm
            // 
            ClientSize = new Size(484, 381);
            Controls.Add(btnList);
            Controls.Add(dataGridView1);
            Controls.Add(btnOrder);
            Controls.Add(btnOrders);
            Controls.Add(btnAdd);
            Name = "ShoesListForm";
            Text = "Lista Butów";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }
        private Button btnList;
    }
}
