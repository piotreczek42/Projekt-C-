using System;
using System.Linq;
using System.Windows.Forms;
using Sklepzbutami_WinForms_NET8.Data;
using Sklepzbutami_WinForms_NET8.Models;

namespace Sklepzbutami_WinForms_NET8.Forms
{
    public partial class ShoesListForm : Form
    {
        private readonly StoreContext _context;

        public ShoesListForm(StoreContext context)
        {
            InitializeComponent();
            _context = context;
            LoadShoes();
        }

        private void LoadShoes()
        {
            var shoes = _context.Shoes
                .Select(s => new { s.Id, s.Name, s.Price })
                .ToList();
            dataGridView1.DataSource = shoes;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var createForm = new CreateShoeForm(_context);
            createForm.FormClosed += (s, args) => LoadShoes(); // od�wie� po dodaniu
            createForm.ShowDialog();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            var orderForm = new CreateOrderForm(_context);
            orderForm.ShowDialog();
        }

        private void btnListaZamowien_Click(object sender, EventArgs e)
        {
            var ordersListForm = new OrdersListForm(_context);
            ordersListForm.ShowDialog();
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            var listForm = new OrdersListForm(_context);
            listForm.ShowDialog();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            var ordersForm = new OrdersListForm(_context);
            ordersForm.ShowDialog();
        }
    }
}
