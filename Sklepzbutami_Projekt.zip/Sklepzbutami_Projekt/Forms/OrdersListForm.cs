﻿using Microsoft.EntityFrameworkCore;
using Sklepzbutami_WinForms_NET8.Data;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sklepzbutami_WinForms_NET8.Forms
{
    public partial class OrdersListForm : Form
    {
        private readonly StoreContext _context;

        public string Description { get; private set; }

        public OrdersListForm(StoreContext context)
        {
            InitializeComponent();
            _context = context;
            LoadOrdersAsync(); // asynchroniczne ładowanie zamówień
        }

        private async void LoadOrdersAsync()
        {
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Shoe)
                .ToListAsync();

            var orderList = orders.Select(order => new
            {
                order.Id,
                order.CustomerName,
                order.Address,
                order.PostalCode,
                Products = string.Join(", ", order.OrderItems.Select(i => $"{i.Shoe.Name} (x{i.Quantity})")),
                TotalPrice = order.OrderItems.Sum(i => i.Quantity * i.Shoe.Price)
            }).ToList();

            dataGridView1.DataSource = orderList;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // na razie puste
        }

        private void txtDescription_TextChanged(object sender, EventArgs e)
        {
         

        }
    }
}
