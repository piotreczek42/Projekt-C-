using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Sklepzbutami_WinForms_NET8.Data;
using Sklepzbutami_WinForms_NET8.Models;

namespace Sklepzbutami_WinForms_NET8.Forms
{
    public partial class CreateOrderForm : Form
    {
        private readonly StoreContext _context;

        public CreateOrderForm(StoreContext context)
        {
            InitializeComponent();
            _context = context;
            LoadShoes();
        }
        private void LoadShoes()
        {
            var shoes = _context.Shoes.ToList();
            checkedListBoxShoes.DataSource = shoes;
            checkedListBoxShoes.DisplayMember = "Name";
            checkedListBoxShoes.ValueMember = "Id";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var name = txtCustomer.Text;
            var address = txtAddress.Text;
            var postalCode = "00-000"; // Można dodać pole kodu później

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Podaj dane klienta.");
                return;
            }

            var selectedIds = checkedListBoxShoes.CheckedItems
                .Cast<Shoe>()
                .Select(s => s.Id)
                .ToList();

            if (selectedIds.Count == 0)
            {
                MessageBox.Show("Wybierz przynajmniej jeden produkt.");
                return;
            }

            var create = _context.Orders.ToList();

            var order = new Order
            {
                CustomerName = name,
                Address = address,
                PostalCode = postalCode,
                OrderDate = DateTime.UtcNow // ✅ ustawia czas w UTC
            };

            _context.Orders.Add(order);
            _context.SaveChanges(); // zapisujemy zamówienie i uzyskujemy jego ID

            foreach (var shoeId in selectedIds)
            {
                var orderItem = new OrderItem
                {
                    OrderId = order.Id,
                    ShoeId = shoeId,
                    Quantity = 1 // domyślnie 1, można rozbudować o wybór
                };
                _context.OrderItems.Add(orderItem);
            }

            _context.SaveChanges();

            MessageBox.Show("Zamówienie zapisane.");
            this.Close();
        }

        private void checkedListBoxShoes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
