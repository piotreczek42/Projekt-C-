namespace Sklepzbutami_WinForms_NET8.Forms
{
    partial class CreateOrderForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.TextBox txtCustomer;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.CheckedListBox checkedListBoxShoes;
        private System.Windows.Forms.Button btnSave;

        private void InitializeComponent()
        {
            lblCustomer = new Label();
            txtCustomer = new TextBox();
            lblAddress = new Label();
            txtAddress = new TextBox();
            checkedListBoxShoes = new CheckedListBox();
            btnSave = new Button();
            SuspendLayout();
            // 
            // lblCustomer
            // 
            lblCustomer.Location = new Point(12, 15);
            lblCustomer.Name = "lblCustomer";
            lblCustomer.Size = new Size(62, 23);
            lblCustomer.TabIndex = 0;
            lblCustomer.Text = "Klient:";
            // 
            // txtCustomer
            // 
            txtCustomer.Location = new Point(80, 12);
            txtCustomer.Name = "txtCustomer";
            txtCustomer.Size = new Size(200, 23);
            txtCustomer.TabIndex = 1;
            // 
            // lblAddress
            // 
            lblAddress.Location = new Point(12, 45);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(62, 23);
            lblAddress.TabIndex = 2;
            lblAddress.Text = "Adres:";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(80, 42);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(200, 23);
            txtAddress.TabIndex = 3;
            // 
            // checkedListBoxShoes
            // 
            checkedListBoxShoes.Location = new Point(12, 75);
            checkedListBoxShoes.Name = "checkedListBoxShoes";
            checkedListBoxShoes.Size = new Size(268, 94);
            checkedListBoxShoes.TabIndex = 4;
            checkedListBoxShoes.SelectedIndexChanged += checkedListBoxShoes_SelectedIndexChanged;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(80, 190);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 5;
            btnSave.Text = "Zapisz zamówienie";
            btnSave.Click += btnSave_Click;
            // 
            // CreateOrderForm
            // 
            ClientSize = new Size(300, 240);
            Controls.Add(lblCustomer);
            Controls.Add(txtCustomer);
            Controls.Add(lblAddress);
            Controls.Add(txtAddress);
            Controls.Add(checkedListBoxShoes);
            Controls.Add(btnSave);
            Name = "CreateOrderForm";
            Text = "Nowe zamówienie";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
