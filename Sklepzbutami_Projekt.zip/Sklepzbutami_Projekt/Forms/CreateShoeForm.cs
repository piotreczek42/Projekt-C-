using Sklepzbutami_WinForms_NET8.Data;
using Sklepzbutami_WinForms_NET8.Models;
using System;
using System.Windows.Forms;

namespace Sklepzbutami_WinForms_NET8.Forms
{
    public partial class CreateShoeForm : Form
    {
        private readonly StoreContext _context;

        public CreateShoeForm(StoreContext context)
        {
            InitializeComponent();
            _context = context;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            var supplier = _context.Suppliers.First();
            var shoe = new Shoe
            {
                Name = txtName.Text,
                Price = decimal.Parse(txtPrice.Text),
                Description = txtDescription.Text,
                Supplier = supplier
            };

            _context.Shoes.Add(shoe);
            _context.SaveChanges();
            MessageBox.Show("Dodano but.");
            Close(); // zamknięcie formularza
        }
    }
}
