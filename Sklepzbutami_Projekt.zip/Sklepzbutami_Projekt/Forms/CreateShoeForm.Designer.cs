namespace Sklepzbutami_WinForms_NET8.Forms
{
    partial class CreateShoeForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Button btnSave;

        private void InitializeComponent()
        {
            lblName = new Label();
            txtName = new TextBox();
            lblPrice = new Label();
            txtPrice = new TextBox();
            btnSave = new Button();
            label1 = new Label();
            txtDescription = new TextBox();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.Location = new Point(12, 15);
            lblName.Name = "lblName";
            lblName.Size = new Size(52, 23);
            lblName.TabIndex = 0;
            lblName.Text = "Nazwa:";
            // 
            // txtName
            // 
            txtName.Location = new Point(70, 12);
            txtName.Name = "txtName";
            txtName.Size = new Size(377, 23);
            txtName.TabIndex = 1;
            // 
            // lblPrice
            // 
            lblPrice.Location = new Point(12, 50);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(40, 23);
            lblPrice.TabIndex = 2;
            lblPrice.Text = "Cena:";
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(70, 47);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(377, 23);
            txtPrice.TabIndex = 3;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(70, 135);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 4;
            btnSave.Text = "Zapisz";
            btnSave.Click += btnSave_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 95);
            label1.Name = "label1";
            label1.Size = new Size(34, 15);
            label1.TabIndex = 5;
            label1.Text = "Opis:";
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(70, 92);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(377, 23);
            txtDescription.TabIndex = 6;
            // 
            // CreateShoeForm
            // 
            ClientSize = new Size(459, 249);
            Controls.Add(txtDescription);
            Controls.Add(label1);
            Controls.Add(lblName);
            Controls.Add(txtName);
            Controls.Add(lblPrice);
            Controls.Add(txtPrice);
            Controls.Add(btnSave);
            Name = "CreateShoeForm";
            Text = "Dodaj Nowy Produkt";
            ResumeLayout(false);
            PerformLayout();
        }
        private Label label1;
        private TextBox txtDescription;
    }
}
